package com.example.L12MinorProject_VMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class L12MinorProjectVmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
