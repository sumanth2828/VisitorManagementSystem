package com.example.L12MinorProject_VMS.controller;


import com.example.L12MinorProject_VMS.dto.VisitDTO;
import com.example.L12MinorProject_VMS.dto.VisitorDTO;
import com.example.L12MinorProject_VMS.service.GatekeeperService;
import jakarta.validation.Valid;
import org.apache.coyote.BadRequestException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

@RestController
@RequestMapping("/gatekeeper")

public class GatekeeperConroller {
    private Logger logger= LoggerFactory.getLogger(GatekeeperConroller.class);
    @Autowired
    private GatekeeperService gatekeeperService;

    @Value("${image.upload.home}")
    private String imageUploadHome;

    @Value("${static.domain.name}")
    private String staticDomainName;

    @GetMapping("/getVisitorById")
    ResponseEntity<VisitorDTO> getVisitorByIdnumber(@RequestParam String idNumber){
        VisitorDTO visitorDTO=gatekeeperService.getVisitorByIdnumber(idNumber);
        if(visitorDTO==null)
            return ResponseEntity.notFound().build();
        return ResponseEntity.ok(visitorDTO);
    }

    @PostMapping("/createVisior")
    ResponseEntity<Long> createVisitor(@RequestBody @Valid VisitorDTO visitorDTO){
        Long id=gatekeeperService.createVisitor(visitorDTO);
        return ResponseEntity.ok(id);
    }

    @PostMapping("/createVisit")
    ResponseEntity<Long> createVisit(@RequestBody @Valid VisitDTO visitDTO){
        Long id = gatekeeperService.createVisit(visitDTO);
        return ResponseEntity.ok(id);
    }

    @PutMapping("/markEntry/{id}")
    ResponseEntity<String> markEntry(@PathVariable Long id) throws BadRequestException {
        return ResponseEntity.ok(gatekeeperService.markEntry(id));

    }

    @PutMapping("/markExit/{id}")
    ResponseEntity<String> markExit(@PathVariable Long id) throws BadRequestException {
        return ResponseEntity.ok(gatekeeperService.markExit(id));
    }

    @PostMapping("/image-upload")
    ResponseEntity<String> imageUpload(@RequestParam MultipartFile file){
        String fileName = UUID.randomUUID()+"_"+file.getOriginalFilename();
        String uploadPath = imageUploadHome+fileName;
        String publicUrl =staticDomainName+"content/"+fileName;
//        try {
//            file.transferTo(new File(uploadPath));
//        } catch (IOException e) {
//            logger.error("Exception occured while upload image {}",e);
//            return ResponseEntity.ok("Exception occured");
//        }
//        return ResponseEntity.ok(publicUrl);

        try {

            File uploadDir = new File(imageUploadHome);
            if (!uploadDir.exists()) {
                uploadDir.mkdirs();
            }

            // Save the file to the specified location
            file.transferTo(new File(uploadPath));
        } catch (IOException e) {
            logger.error("Exception occurred while uploading image: {}", e.getMessage());
            return ResponseEntity.ok("Exception occurred while uploading image: " + e.getMessage());
        }
        return ResponseEntity.ok(publicUrl);
    }
}
