package com.example.L12MinorProject_VMS.service;

import com.example.L12MinorProject_VMS.dto.AddressDTO;
import com.example.L12MinorProject_VMS.dto.UserDTO;
import com.example.L12MinorProject_VMS.entity.Address;
import com.example.L12MinorProject_VMS.entity.Flat;
import com.example.L12MinorProject_VMS.entity.User;
import com.example.L12MinorProject_VMS.enums.Role;
import com.example.L12MinorProject_VMS.enums.UserStatus;
import com.example.L12MinorProject_VMS.repo.FlatRepo;
import com.example.L12MinorProject_VMS.repo.UserRepo;
import com.example.L12MinorProject_VMS.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AdminService {

    @Autowired
    private FlatRepo flatRepo;

    @Autowired
    private UserRepo userRepo;

    @Autowired
    private CommonUtil commonUtil;

    public Long createUser(UserDTO userDTO){
        AddressDTO addressDTO=userDTO.getAddress();
        Address address=commonUtil.convertAddressDTOTO(addressDTO);

        Flat flat=null;
        if(userDTO.getFlatNo()!=null){
            flat=flatRepo.findByNumber(userDTO.getFlatNo());
        }
        User user= User.builder().
                name(userDTO.getName()).
                email(userDTO.getEmail()).
                phone(userDTO.getPhone()).
                role(Role.valueOf(userDTO.getRole())).
                userStatus(UserStatus.ACTIVE).
                idNumber(userDTO.getIdNumber()).flat(flat).address(address).
                build();
        user =userRepo.save(user);
        return user.getId();
    }
}
