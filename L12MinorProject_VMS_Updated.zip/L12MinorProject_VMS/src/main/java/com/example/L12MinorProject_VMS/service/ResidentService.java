package com.example.L12MinorProject_VMS.service;

import com.example.L12MinorProject_VMS.Exception.NotFoundException;
import com.example.L12MinorProject_VMS.dto.VisitDTO;
import com.example.L12MinorProject_VMS.entity.Flat;
import com.example.L12MinorProject_VMS.entity.User;
import com.example.L12MinorProject_VMS.entity.Visit;
import com.example.L12MinorProject_VMS.entity.Visitor;
import com.example.L12MinorProject_VMS.enums.VisitStatus;
import com.example.L12MinorProject_VMS.repo.UserRepo;
import com.example.L12MinorProject_VMS.repo.VisitRepo;
import com.example.L12MinorProject_VMS.repo.VisitorRepo;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ResidentService {

    @Autowired
    private VisitRepo visitRepo;
    @Autowired
    private UserRepo userRepo;

    public String updateStatus(Long id, VisitStatus visitStatus) throws BadRequestException {
        if(visitStatus!=VisitStatus.APPROVED && visitStatus!=VisitStatus.REJECTED){
            throw new BadRequestException("Invalid status transition");
        }
        Visit visit=visitRepo.findById(id).get();
        if(visit==null){
            throw new NotFoundException("Visit not found");
        }
        if(VisitStatus.WAITING.equals(visit.getVisitStatus())){
            visit.setVisitStatus(visitStatus);
            visitRepo.save(visit);
        }else{
            throw new BadRequestException("Invalid status transition");
        }
        return "Done";
    }

    public List<VisitDTO> getPendingList(Long userId){
        User user=userRepo.findById(userId).get();
        Flat flat=user.getFlat();
        List<Visit> visitList=  visitRepo.findByvisitStatusAndFlat(VisitStatus.WAITING,flat);
        List<VisitDTO> visitDTOList=new ArrayList<>();
        for(Visit visit:visitList){
            Visitor visitor=visit.getVisitor();
            VisitDTO visitDTO=VisitDTO.builder()
                    .flatNumber(flat.getNumber())
                    .visitStatus(visit.getVisitStatus())
                    .purpose(visit.getPurpose())
                    .imageUrl(visit.getImageUrl())
                    .noOfPeople(visit.getNoOfPeople())
                    .visitorName(visitor.getName())
                    .visitorPhone(visitor.getPhone())
                    .idNumber(visitor.getIdNumber())
                    .build();
            visitDTOList.add(visitDTO);
        }
        return visitDTOList;
    }
}
