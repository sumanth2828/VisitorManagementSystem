package com.example.L12MinorProject_VMS.repo;

import com.example.L12MinorProject_VMS.entity.Flat;
import com.example.L12MinorProject_VMS.entity.Visit;
import com.example.L12MinorProject_VMS.enums.VisitStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VisitRepo extends JpaRepository<Visit, Long> {
    List<Visit> findByvisitStatusAndFlat(VisitStatus visitStatus, Flat flat);
}
