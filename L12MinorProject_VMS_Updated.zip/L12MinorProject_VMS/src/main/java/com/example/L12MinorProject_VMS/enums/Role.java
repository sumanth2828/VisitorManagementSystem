package com.example.L12MinorProject_VMS.enums;

public enum Role {
    ADMIN,GATEKEEPER,RESIDENT
}
