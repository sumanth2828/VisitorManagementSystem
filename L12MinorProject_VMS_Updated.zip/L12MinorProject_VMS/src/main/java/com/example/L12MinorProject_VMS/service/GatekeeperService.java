package com.example.L12MinorProject_VMS.service;

import com.example.L12MinorProject_VMS.dto.AddressDTO;
import com.example.L12MinorProject_VMS.dto.VisitDTO;
import com.example.L12MinorProject_VMS.dto.VisitorDTO;
import com.example.L12MinorProject_VMS.entity.Address;
import com.example.L12MinorProject_VMS.entity.Flat;
import com.example.L12MinorProject_VMS.entity.Visit;
import com.example.L12MinorProject_VMS.entity.Visitor;
import com.example.L12MinorProject_VMS.enums.VisitStatus;
import com.example.L12MinorProject_VMS.repo.FlatRepo;
import com.example.L12MinorProject_VMS.repo.VisitRepo;
import com.example.L12MinorProject_VMS.repo.VisitorRepo;
import com.example.L12MinorProject_VMS.util.CommonUtil;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class GatekeeperService {
    @Autowired
    private VisitorRepo visitorRepo;

    @Autowired
    private FlatRepo flatRepo;

    @Autowired
    private VisitRepo visitRepo;

    @Autowired
    private CommonUtil commonUtil;

    public VisitorDTO getVisitorByIdnumber(String idNumber){
        Visitor visitor=visitorRepo.findByIdNumber(idNumber);
        VisitorDTO visitorDTO=null;
        if(visitor!=null){
            visitorDTO=VisitorDTO.builder()
                    .name(visitor.getName())
                    .email(visitor.getEmail())
                    .phone(visitor.getPhone())
                    .idNumber(visitor.getIdNumber())
                    .build();
        }
        return visitorDTO;
    }

    public Long createVisitor(VisitorDTO visitorDTO){
        AddressDTO addressDTO=visitorDTO.getAddress();
        Address address=commonUtil.convertAddressDTOTO(addressDTO);
        Visitor visitor=Visitor.builder()
                .name(visitorDTO.getName())
                .email(visitorDTO.getEmail())
                .phone(visitorDTO.getPhone())
                .idNumber(visitorDTO.getIdNumber())
                .address(address)
                .build();
        visitor=visitorRepo.save(visitor);
        return visitor.getVisitor_id();
    }

    public Long createVisit(VisitDTO visitDTO){
        Flat flat=flatRepo.findByNumber(visitDTO.getFlatNumber());
        Visitor visitor=visitorRepo.findByIdNumber(visitDTO.getIdNumber());
        Visit visit=Visit.builder()
                .flat(flat)
                .visitStatus(VisitStatus.WAITING)
                .purpose(visitDTO.getPurpose())
                .imageUrl(visitDTO.getImageUrl())
                .noOfPeople(visitDTO.getNoOfPeople())
                .visitor(visitor)
                .build();
        visit=visitRepo.save(visit);
        return visit.getId();
    }

    public String markEntry(Long id) throws BadRequestException {
        Visit visit=visitRepo.findById(id).get();
        if(visit==null){
            throw new BadRequestException("visit not found");
        }
        if( visit.getVisitStatus().equals(VisitStatus.APPROVED)){
           visit.setInTime(new Date());
           visitRepo.save(visit);//this is not required when we keep transactional
        }else{
            throw new BadRequestException("visit not found");
        }
        return "DONE";
    }

    public String markExit(Long id) throws BadRequestException {
        Visit visit=visitRepo.findById(id).get();
        if(visit==null){
            throw new BadRequestException("visit not found");
        }
        if( visit.getVisitStatus().equals(VisitStatus.APPROVED)){
            visit.setOutTime(new Date());
            visit.setVisitStatus(VisitStatus.COMPLETED);
            visitRepo.save(visit);//this is not required when we keep transactional
        }else{
            throw new BadRequestException("visit not found");
        }
        return "DONE";
    }


}
