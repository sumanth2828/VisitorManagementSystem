package com.example.L12MinorProject_VMS.util;

import com.example.L12MinorProject_VMS.dto.AddressDTO;
import com.example.L12MinorProject_VMS.entity.Address;
import org.springframework.stereotype.Component;

@Component
public class CommonUtil {
    public Address convertAddressDTOTO(AddressDTO addressDTO){
        Address address=Address.builder().
                line1(addressDTO.getLine1()).
                line2(addressDTO.getLine2()).
                city(addressDTO.getCity()).
                pincode(addressDTO.getPincode()).
                build();
        return address;
    }
}
