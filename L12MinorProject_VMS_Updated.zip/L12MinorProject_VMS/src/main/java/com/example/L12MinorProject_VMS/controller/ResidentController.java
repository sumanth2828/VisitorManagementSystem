package com.example.L12MinorProject_VMS.controller;


import com.example.L12MinorProject_VMS.dto.VisitDTO;
import com.example.L12MinorProject_VMS.enums.VisitStatus;
import com.example.L12MinorProject_VMS.service.GatekeeperService;
import com.example.L12MinorProject_VMS.service.ResidentService;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/resident")
public class ResidentController {

    @Autowired
    private ResidentService residentService;

    @PutMapping("/actOnVisit/{id}")
    ResponseEntity<String> actOnVisit(@PathVariable Long id, @RequestParam VisitStatus visitStatus) throws BadRequestException {
        return ResponseEntity.ok(residentService.updateStatus(id,visitStatus));
    }

    @GetMapping("/pendingVisits")
    ResponseEntity<List<VisitDTO>> getPendingVisitList(@RequestHeader Long userId){
        return ResponseEntity.ok(residentService.getPendingList(userId));
    }
}
