package com.example.L12MinorProject_VMS.controller;

import com.example.L12MinorProject_VMS.dto.AddressDTO;
import com.example.L12MinorProject_VMS.dto.UserDTO;
import com.example.L12MinorProject_VMS.service.AdminService;
import jakarta.validation.Valid;

import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/admin")

public class AdminController {
    private Logger logger= LoggerFactory.getLogger(AdminController.class);

    @Autowired
    private AdminService adminService;

    @PostMapping("/createUser")
    ResponseEntity<Long> createUser(@RequestBody @Valid UserDTO userDTO){
        Long id=adminService.createUser(userDTO);
        return ResponseEntity.ok(id);
    }

//    @PostMapping("/bulk-user-creation")
//    ResponseEntity<List<String>> createBulkUser(@RequestParam MultipartFile file){
//        logger.error("file path "+ file.getOriginalFilename());
//        List<String> response=new ArrayList<>();
//
//        try{
//            BufferedReader fileReader = new BufferedReader(new InputStreamReader(file.getInputStream()));
//            CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim());
//            List<CSVRecord> csvRecords = csvParser.getRecords();
//            String currentIDno="";
//            for(CSVRecord csvRecord: csvRecords){
//                try {
//                    AddressDTO addressDTO=AddressDTO.builder()
//                            .line1(csvRecord.get("line1"))
//                            .line2(csvRecord.get("line2"))
//                            .city(csvRecord.get("city"))
//                            .pincode(csvRecord.get("pincode"))
//                            .build();
//                    UserDTO userDTO=UserDTO.builder()
//                            .name(csvRecord.get("name"))
//                            .phone(csvRecord.get("phone"))
//                            .role(csvRecord.get("role"))
//                            .idNumber(csvRecord.get("idNumber"))
//                            .userStatus(csvRecord.get("status"))
//                            .address(addressDTO)
//                            .flatNo(csvRecord.get("flatNo"))
//                            .email(csvRecord.get("email"))
//                            .build();
//                    currentIDno=userDTO.getIdNumber();
//                    Long id= adminService.createUser(userDTO);
//                    response.add("user create "+userDTO.getName()+" with id"+id);
//                }catch (Exception e){
//                    response.add("got exception while creating the user "+ currentIDno);
//                }
//            }
//
//        }catch (IOException e) {
//            throw new RuntimeException(e);
//        }
//        return ResponseEntity.ok(response);
//    }

    @PostMapping("/bulk-user-creation")
    ResponseEntity<List<String>> createBulkUser(@RequestParam MultipartFile file) {
        logger.error("file path: " + file.getOriginalFilename());
        List<String> response = new ArrayList<>();

        try (BufferedReader fileReader = new BufferedReader(new InputStreamReader(file.getInputStream()));
             CSVParser csvParser = new CSVParser(fileReader, CSVFormat.DEFAULT.withFirstRecordAsHeader().withIgnoreHeaderCase().withTrim())) {
//             CSVParser csvParser = new CSVParser(fileReader,CSVFormat.DEFAULT.)
            List<CSVRecord> csvRecords = csvParser.getRecords();
            String currentIDno = "";

            for (CSVRecord csvRecord : csvRecords) {
                try {
                    AddressDTO addressDTO = AddressDTO.builder()
                            .line1(csvRecord.get("line1"))
                            .line2(csvRecord.get("line2"))
                            .city(csvRecord.get("city"))
                            .pincode(csvRecord.get("pincode"))
                            .build();

                    UserDTO userDTO = UserDTO.builder()
                            .name(csvRecord.get("name"))
                            .phone(csvRecord.get("phone"))
                            .role(csvRecord.get("role"))
                            .idNumber(csvRecord.get("idNumber"))
                            .userStatus(csvRecord.get("status"))
                            .address(addressDTO)
                            .flatNo(csvRecord.get("flatNo"))
                            .email(csvRecord.get("email"))
                            .build();

                    currentIDno = userDTO.getIdNumber();
                    Long id = adminService.createUser(userDTO);
                    response.add("User created: " + userDTO.getName() + " with ID: " + id);
                } catch (Exception e) {
                    logger.error("Exception while creating user with ID: {}. Error: {}", currentIDno, e.getMessage());
                    response.add("Error creating user with ID: " + currentIDno + ". Error: " + e.getMessage());
                }
            }

        } catch (IOException e) {
            logger.error("Exception while reading the CSV file: {}", e.getMessage());
            response.add("Failed to read the file: " + e.getMessage());
        }

        return ResponseEntity.ok(response);
    }
}
