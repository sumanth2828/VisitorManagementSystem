package com.example.L12MinorProject_VMS.Exception;

public class BadRequestException extends RuntimeException{
    public BadRequestException (String msg){
        super(msg);
    }
}

