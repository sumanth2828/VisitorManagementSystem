package com.example.L12MinorProject_VMS.enums;

public enum VisitStatus {
    WAITING,
    COMPLETED,
    REJECTED,
    APPROVED,
    EXPIRE
}
