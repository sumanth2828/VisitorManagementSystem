package com.example.L12MinorProject_VMS.dto;

import com.example.L12MinorProject_VMS.enums.VisitStatus;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.Date;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class VisitDTO {

    private VisitStatus visitStatus;
    @NonNull
    @Size(max=255)
    private String purpose;

    private Date inTime;

    private Date outTime;

    private String imageUrl;

    private String idNumber;

    @NonNull
    private Integer noOfPeople;
    private String flatNumber;
    private String visitorName;
    private String visitorPhone;
}
