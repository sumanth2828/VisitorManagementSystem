package com.example.L12MinorProject_VMS.Exception;

public class NotFoundException extends RuntimeException{
    public NotFoundException (String msg){
        super(msg);
    }
}
