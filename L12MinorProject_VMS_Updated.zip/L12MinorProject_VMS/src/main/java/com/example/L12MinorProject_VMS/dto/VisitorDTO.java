package com.example.L12MinorProject_VMS.dto;

import com.example.L12MinorProject_VMS.entity.Address;
import com.fasterxml.jackson.annotation.JsonInclude;
import jakarta.persistence.Column;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)

public class VisitorDTO {

    @NonNull
    @Size(max = 255)
    private String name;

    @NonNull
    @Size(max = 255)
    private String email;

    @NonNull
    @Size(max = 10)
    private String phone;

    @NonNull
    private String idNumber;

    private AddressDTO address;

}

